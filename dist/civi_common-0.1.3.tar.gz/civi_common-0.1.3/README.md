# civi-common
Common services for working with Microsoft Fabric